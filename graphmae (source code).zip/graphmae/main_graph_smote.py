import logging
from tqdm import tqdm
import numpy as np

import dgl
from dgl.nn.pytorch.glob import SumPooling, AvgPooling, MaxPooling
from dgl.dataloading import GraphDataLoader

import torch
from torch.utils.data.sampler import SubsetRandomSampler

from sklearn.model_selection import StratifiedKFold, GridSearchCV
from sklearn.svm import SVC
from sklearn.metrics import f1_score
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import RepeatedStratifiedKFold

import imblearn
from imblearn.over_sampling import RandomOverSampler
from collections import Counter
from imblearn.over_sampling import SMOTE

from graphmae.utils import (
    build_args,
    create_optimizer,
    set_random_seed,
    TBLogger,
    get_current_lr,
    load_best_configs,
)
from graphmae.datasets.data_util import load_graph_classification_dataset
from graphmae.models import build_model
from sklearn.metrics import recall_score

def graph_classification_evaluation(model, pooler, dataloader, num_classes, lr_f, weight_decay_f, max_epoch_f, device,
                                    mute=False):
    model.eval()
    x_list = []
    y_list = []
    with torch.no_grad():
        for i, (batch_g, labels) in enumerate(dataloader):
            batch_g = batch_g.to(device)
            print("================", batch_g)
            feat = batch_g.ndata["attr"]
            print("================", feat)

            out = model.embed(batch_g, feat)
            print("=======outdembed=========", out)

            out = pooler(batch_g, out)
            print("========out========", batch_g)

            y_list.append(labels.numpy())
            print("========y_list========", y_list)

            x_list.append(out.cpu().numpy())
            print("========x_list========", x_list)
    x = np.concatenate(x_list, axis=0)
    print("========x========", x)

    y = np.concatenate(y_list, axis=0)
    unique, counts = np.unique(y, return_counts=True)
    print("========%%%%%%%%%%%%%y%%%%%%%%%%%========", dict(zip(unique, counts)))
    # print("@@@@@@@@@@@ y_list @@@@@@@@@@@", Counter(y_list))

    # Mahmoud
    # print("Counter(y):  ", Counter(y), "Counter(x):  ", Counter (x))
    counter = Counter(y)
    print("Before:   ", counter)

    #oversample = SMOTE()
    x_over, y_over = SMOTE(sampling_strategy=0.3, random_state=100, k_neighbors=3).fit_resample(x, y)
    # print("========y_over count 1  %s %s========"% (y_over.count(1), y_over.count(0)))
    # summarize the new class distribution
    counter = Counter(y)
    print("After:   ", counter)
    # scatter plot of examples by class label
    # for label, _ in counter.items():
    #     row_ix = where(y == label)[0]
    #     pyplot.scatter(X[row_ix, 0], X[row_ix, 1], label=str(label))
    # pyplot.legend()
    # pyplot.show()




    print("@@@@@@@@@@@ y_over @@@@@@@@@@@", Counter(y_over))

    # test_f1, test_std = evaluate_graph_embeddings_using_svm(x, y)
    test_f1, test_std = evaluate_graph_embeddings_using_svm(x_over, y_over)

    print(f"#Test_f1: {test_f1:.4f}±{test_std:.4f}")
    return test_f1


def evaluate_graph_embeddings_using_svm(embeddings, labels):
    result = []
    resultrec2 = []

    kf = StratifiedKFold(n_splits=10, shuffle=True, random_state=100)
    # kf = RepeatedStratifiedKFold(n_splits=10, n_repeats=5, random_state=42)

    print("---------------------------", kf)
    y_final = []
    pred_final = []
    for train_index, test_index in kf.split(embeddings, labels):
        x_train = embeddings[train_index]
        print("========evaluate_graph_embeddings_using_svm(x_train========", x_train)

        x_test = embeddings[test_index]
        print("========evaluate_graph_embeddings_using_svm(x_test========", x_test)

        y_train = labels[train_index]
        print("========evaluate_graph_embeddings_using_svm(y_train========", y_train)

        y_test = labels[test_index]
        print("========evaluate_graph_embeddings_using_svm(y_test========", y_test)

        params = {"C": [1e-3, 1e-2, 1e-1, 1, 10]}
        svc = SVC(random_state=100)
        clf = GridSearchCV(svc, params)
        clf.fit(x_train, y_train)

        preds = clf.predict(x_test)
        print("##########Preds:  ################", preds)
        f1 = f1_score(y_test, preds, average="micro")
        rec2 = recall_score(y_test, preds, average=None, labels=[1, 0])

        pred_final = np.concatenate((pred_final, preds), axis=None)
        y_final = np.concatenate((y_final, y_test), axis=None)
        print("## pred_final ##",pred_final)
        print("## y_final ##",y_final)
        resultrec2.append(rec2)

        result.append(f1)

    print(classification_report(y_final, pred_final))
    print("***************recall***************", resultrec2)

    print("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
    print(confusion_matrix(y_final, pred_final))
    test_f1 = np.mean(result)
    print("test f1:          ", test_f1)
    test_std = np.std(result)
    print("test std:          ", test_std)

    return test_f1, test_std


def pretrain(model, pooler, dataloaders, optimizer, max_epoch, device, scheduler, num_classes, lr_f, weight_decay_f,
             max_epoch_f, linear_prob=True, logger=None):
    train_loader, eval_loader = dataloaders

    epoch_iter = tqdm(range(max_epoch))
    for epoch in epoch_iter:
        model.train()
        loss_list = []
        for batch in train_loader:
            batch_g, _ = batch
            batch_g = batch_g.to(device)
            print("******************  ", batch_g, "**********************")

            feat = batch_g.ndata["attr"]
            print("******************  ", feat, "**********************")
            model.train()
            loss, loss_dict = model(batch_g, feat)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            loss_list.append(loss.item())
            if logger is not None:
                loss_dict["lr"] = get_current_lr(optimizer)
                logger.note(loss_dict, step=epoch)
        if scheduler is not None:
            scheduler.step()
        epoch_iter.set_description(f"Epoch {epoch} | train_loss: {np.mean(loss_list):.4f}")

    return model


def collate_fn(batch):
    # graphs = [x[0].add_self_loop() for x in batch]
    graphs = [x[0] for x in batch]
    labels = [x[1] for x in batch]
    batch_g = dgl.batch(graphs)
    labels = torch.cat(labels, dim=0)
    return batch_g, labels


def main(args):
    device = args.device if args.device >= 0 else "cpu"
    seeds = args.seeds
    dataset_name = args.dataset
    max_epoch = args.max_epoch
    max_epoch_f = args.max_epoch_f
    num_hidden = args.num_hidden
    num_layers = args.num_layers
    encoder_type = args.encoder
    decoder_type = args.decoder
    replace_rate = args.replace_rate

    optim_type = args.optimizer
    loss_fn = args.loss_fn

    lr = args.lr
    weight_decay = args.weight_decay
    lr_f = args.lr_f
    weight_decay_f = args.weight_decay_f
    linear_prob = args.linear_prob
    load_model = args.load_model
    save_model = args.save_model
    logs = args.logging
    use_scheduler = args.scheduler
    pooling = args.pooling
    deg4feat = args.deg4feat
    batch_size = args.batch_size

    print("DATASET SELECTED --", dataset_name)
    graphs, (num_features, num_classes) = load_graph_classification_dataset(dataset_name, deg4feat=deg4feat)
    args.num_features = num_features

    train_idx = torch.arange(len(graphs))
    train_sampler = SubsetRandomSampler(train_idx)

    train_loader = GraphDataLoader(graphs, sampler=train_sampler, collate_fn=collate_fn, batch_size=batch_size,
                                   pin_memory=True)
    eval_loader = GraphDataLoader(graphs, collate_fn=collate_fn, batch_size=batch_size, shuffle=False)

    if pooling == "mean":
        pooler = AvgPooling()
    elif pooling == "max":
        pooler = MaxPooling()
    elif pooling == "sum":
        pooler = SumPooling()
    else:
        raise NotImplementedError

    acc_list = []
    for i, seed in enumerate(seeds):
        print(f"####### Run {i} for seed {seed}")
        set_random_seed(seed)

        if logs:
            logger = TBLogger(
                name=f"{dataset_name}_loss_{loss_fn}_rpr_{replace_rate}_nh_{num_hidden}_nl_{num_layers}_lr_{lr}_mp_{max_epoch}_mpf_{max_epoch_f}_wd_{weight_decay}_wdf_{weight_decay_f}_{encoder_type}_{decoder_type}")
        else:
            logger = None

        model = build_model(args)
        model.to(device)
        optimizer = create_optimizer(optim_type, model, lr, weight_decay)

        if use_scheduler:
            logging.info("Use schedular")
            scheduler = lambda epoch: (1 + np.cos((epoch) * np.pi / max_epoch)) * 0.5
            # scheduler = lambda epoch: epoch / warmup_steps if epoch < warmup_steps \
            # else ( 1 + np.cos((epoch - warmup_steps) * np.pi / (max_epoch - warmup_steps))) * 0.5
            scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=scheduler)
        else:
            scheduler = None

        if not load_model:
            model = pretrain(model, pooler, (train_loader, eval_loader), optimizer, max_epoch, device, scheduler,
                             num_classes, lr_f, weight_decay_f, max_epoch_f, linear_prob, logger)
            model = model.cpu()

        if load_model:
            logging.info("Loading Model ... ")
            model.load_state_dict(torch.load("checkpoint.pt"))
        if save_model:
            logging.info("Saveing Model ...")
            torch.save(model.state_dict(), "checkpoint.pt")

        model = model.to(device)
        model.eval()
        test_f1 = graph_classification_evaluation(model, pooler, eval_loader, num_classes, lr_f, weight_decay_f,
                                                  max_epoch_f, device, mute=False)
        acc_list.append(test_f1)

    final_acc, final_acc_std = np.mean(acc_list), np.std(acc_list)
    print(f"# final_acc: {final_acc:.4f}±{final_acc_std:.4f}")


if __name__ == "__main__":
    args = build_args()
    if args.use_cfg:
        args = load_best_configs(args, "configs.yml")
    print(args)
    main(args)
