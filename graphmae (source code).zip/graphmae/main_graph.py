import logging

import torchvision.utils
from tqdm import tqdm
import numpy as np

import os
import shutil


import dgl
from dgl.nn.pytorch.glob import SumPooling, AvgPooling, MaxPooling
from dgl.dataloading import GraphDataLoader

import torch
from torch.utils.data.sampler import SubsetRandomSampler
import matplotlib.pyplot as plt
from sklearn.model_selection import StratifiedKFold, GridSearchCV
from sklearn.svm import SVC
import pandas as pd
from sklearn.metrics import accuracy_score
from matplotlib import pyplot
import matplotlib.pyplot as plt

from torch.utils.tensorboard import SummaryWriter
#from tensorboardX import SummaryWriter
import torch.multiprocessing
torch.multiprocessing.set_sharing_strategy('file_system')

writer = SummaryWriter("runs/GraphVUL")

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression

from sklearn.model_selection import RepeatedStratifiedKFold
import sys
import imblearn
from imblearn.over_sampling import RandomOverSampler
from collections import Counter
from sklearn import metrics

from graphmae.utils import (
    build_args,
    create_optimizer,
    set_random_seed,
    TBLogger,
    get_current_lr,
    load_best_configs,
)
from graphmae.datasets.data_util import load_graph_classification_dataset
from graphmae.models import build_model

from sklearn.metrics import PrecisionRecallDisplay
from sklearn.metrics import recall_score, classification_report, f1_score, confusion_matrix, precision_recall_fscore_support
from tensorflow.python.keras.callbacks import Callback
#global resultrec2


# #Mahmoud Plot for Recall
# # callback to find metrics at epoch end   #Added by Mahmoud
# class Metrics(Callback):
#     def __init__(self, x, y):
#         self.x = x
#         self.y = y if (y.ndim == 1 or y.shape[1] == 1) else np.argmax(y, axis=1)
#         self.reports = []
#
#     def on_epoch_end(self, epoch, logs={}):
#         y_hat = np.asarray(self.model.predict(self.x))
#         y_hat = np.where(y_hat > 0.5, 1, 0) if (y_hat.ndim == 1 or y_hat.shape[1] == 1) else np.argmax(y_hat, axis=1)
#         report = classification_report(self.y, y_hat, output_dict=True)
#         self.reports.append(report)
#         return
#
#     # Utility method
#     def get(self, metrics, of_class):
#         return [report[str(of_class)][metrics] for report in self.reports]



def graph_classification_evaluation(model, pooler, dataloader, num_classes, lr_f, weight_decay_f, max_epoch_f, device, mute=False):
    model.eval()
    x_list = []
    y_list = []
    with torch.no_grad():
        for i, (batch_g, labels) in enumerate(dataloader):
            batch_g = batch_g.to(device)
            print("================", batch_g)
            feat = batch_g.ndata["attr"]
            print("================", feat)

            out = model.embed(batch_g, feat)
            print("=======outdembed=========", out)

            out = pooler(batch_g, out)
            print("========out========", batch_g)

            y_list.append(labels.numpy())
            print("========y_list========", y_list)

            x_list.append(out.cpu().numpy())
            print("========x_list========", x_list)
    x = np.concatenate(x_list, axis=0)
    print("========x========", x)

    y = np.concatenate(y_list, axis=0)
    unique, counts = np.unique(y, return_counts=True)
    print("========%%%%%%%%%%%%%y%%%%%%%%%%%========", dict(zip(unique, counts)))
    #print("@@@@@@@@@@@ y_list @@@@@@@@@@@", Counter(y_list))

    # Mahmoud
    #print("Counter(y):  ", Counter(y), "Counter(x):  ", Counter (x))
    oversample = RandomOverSampler(sampling_strategy=0.3, random_state=100)
    x_over, y_over = oversample.fit_resample(x, y)
    #print("========y_over count 1  %s %s========"% (y_over.count(1), y_over.count(0)))

    print("@@@@@@@@@@@ y_over @@@@@@@@@@@", Counter(y_over))
    # img_grid = torchvision.utils.make_grid()
    # writer.('GraphVUL',img_grid)
    # writer.close()
    #test_f1, test_std = evaluate_graph_embeddings_using_svm(x, y)
    test_f1, test_std = evaluate_graph_embeddings_using_svm(x_over, y_over)

    print(f"#Test_f1: {test_f1:.4f}±{test_std:.4f}")
    return test_f1


def evaluate_graph_embeddings_using_svm(embeddings, labels):
    result = []
    resultrec1= []
    resultrec2 = []

    kf = StratifiedKFold(n_splits=10, shuffle=True, random_state=100)   # 42 -->0
    #kf = RepeatedStratifiedKFold(n_splits=10, n_repeats=5, random_state=42)

    print("---------------------------", kf)
    y_final = []
    pred_final = []
    for train_index, test_index in kf.split(embeddings, labels):
        x_train = embeddings[train_index]
        print("========evaluate_graph_embeddings_using_svm(x_train========", x_train)

        x_test = embeddings[test_index]
        print("========evaluate_graph_embeddings_using_svm(x_test========", x_test)

        y_train = labels[train_index]
        print("========evaluate_graph_embeddings_using_svm(y_train========", y_train)

        y_test = labels[test_index]
        print("========evaluate_graph_embeddings_using_svm(y_test========", y_test)

        params = {"C": [1e-3, 1e-2,
                        1e-1, 1, 10]}
        svc = SVC(random_state=100)
        clf = GridSearchCV(svc, params)

        #Mahmoud for plot recall for each epoch which is not done!
        #metrics_binary = Metrics(x_train, y_train)

        clf.fit(x_train, y_train) #Original before
        #clf.fit(x_train, y_train, epochs=2, callbacks=[metrics_binary])

        preds = clf.predict(x_test)

        # print("##########Preds:  ################",preds)
        f1 = f1_score(y_test, preds, average="micro")
        # print("##########f1:  ################",f1)
        # print(classification_report(y_test, preds))


        #rec1 = precision_recall_fscore_support(y_test, preds, average=None, labels=[1, 0])
        #print("***************Rec with precision_recall_fscore_support ***************", rec1)
        rec2 = recall_score(y_test, preds, average=None, labels=[1, 0])

        pred_final = np.concatenate((pred_final, preds), axis=None)
        y_final = np.concatenate((y_final, y_test), axis=None)
        print("## pred_final ##",pred_final)
        print("## y_final ##",y_final)
        result.append(f1)
        #resultrec1.append(rec1)
        resultrec2.append(rec2)
        #print("AvgRecall-1:   ", rec1.mean())
        #print("AvgRecall-1:   ", rec2.mean())

        # display = PrecisionRecallDisplay.from_estimator( clf, x_test, y_test, name="LinearSVC")   #Mahmoud
        # _ = display.ax_.set_title("2-class Precision-Recall curve")

        #Mahmoud for plot recall for each epoch which is not done!

        # Plotting
    print(classification_report(y_final, pred_final))
    print("***************recall***************", resultrec2)




    # fpr, tpr, _ = metrics.roc_curve(y_final, pred_final)
    # # create ROC curve
    # plt.plot(fpr, tpr)
    # plt.ylabel('True Positive Rate')
    # plt.xlabel('False Positive Rate')
    # plt.show()
    # auc = metrics.roc_auc_score(y_final, pred_final)
    # # create AUC curve
    # plt.plot(fpr, tpr, label="AUC=" + str(auc))
    # plt.ylabel('True Positive Rate')
    # plt.xlabel('False Positive Rate')
    # plt.legend(loc=4)
    # plt.show()


    print("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")

    print(confusion_matrix(y_final, pred_final))
    test_f1 = np.mean(result)
    print("test f1:          ", test_f1)
    test_std = np.std(result)
    print("test std:          ", test_std)

    return test_f1, test_std




#Mahmoud EralyStopping

class EarlyStopper:
    def __init__(self, patience=1, min_delta=0):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.min_validation_loss = np.inf

    def early_stop(self, validation_loss):
        if validation_loss < self.min_validation_loss:
            self.min_validation_loss = validation_loss
            self.counter = 0
        elif validation_loss > (self.min_validation_loss + self.min_delta):
            self.counter += 1
            if self.counter >= self.patience:
                return True
        return False





def pretrain(model, pooler, dataloaders, optimizer, max_epoch, device, scheduler, num_classes, lr_f, weight_decay_f, max_epoch_f, linear_prob=True, logger=None):
    train_loader, eval_loader = dataloaders
    early_stopper = EarlyStopper(patience=3, min_delta=10)
    epoch_iter = tqdm(range(max_epoch))
    #print("@@@@@@@@@@@@@@@@@@@@@@@@@  ", resultrec2)
    for epoch in epoch_iter:
        model.train()
        loss_list = []
        for batch in train_loader:
            batch_g, _ = batch
            batch_g = batch_g.to(device)
            print("******************  ", batch_g, "**********************")

            feat = batch_g.ndata["attr"]
            print("******************  ", feat, "**********************")
            model.train()

            loss, loss_dict = model(batch_g, feat)
            #loss = loss.numpy(),
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            loss_list.append(loss.item())
            #print("################### Lossitem ###################",loss.item)

            if logger is not None:
                loss_dict["lr"] = get_current_lr(optimizer)
                logger.note(loss_dict, step=epoch)

        if scheduler is not None:
            scheduler.step()


        validation_loss = np.mean(loss_list)
        if early_stopper.early_stop(validation_loss):          #Mahmoud 11-17-2022
            break



        epoch_iter.set_description(f"Epoch {epoch} | train_loss: {validation_loss:.4f}")

    return model


# # Function to calculate Precision and Recall
#
# def calc_precision_recall(y_true, y_pred):
#     # Convert predictions to series with index matching y_true
#     y_pred = pd.Series(y_pred, index=y_true.index)
#
#     # Instantiate counters
#     TP = 0
#     FP = 0
#     FN = 0
#
#     # Determine whether each prediction is TP, FP, TN, or FN
#     for i in y_true.index:
#         if y_true[i] == y_pred[i] == 1:
#             TP += 1
#         if y_pred[i] == 1 and y_true[i] != y_pred[i]:
#             FP += 1
#         if y_pred[i] == 0 and y_test[i] != y_pred[i]:
#             FN += 1
#
#     # Calculate true positive rate and false positive rate
#     # Use try-except statements to avoid problem of dividing by 0
#     try:
#         precision = TP / (TP + FP)
#     except:
#         precision = 1
#
#     try:
#         recall = TP / (TP + FN)
#     except:
#         recall = 1
#
#     return precision, recall
def collate_fn(batch):
    # graphs = [x[0].add_self_loop() for x in batch]
    graphs = [x[0] for x in batch]
    labels = [x[1] for x in batch]
    batch_g = dgl.batch(graphs)
    labels = torch.cat(labels, dim=0)
    return batch_g, labels


def main(args):
    device = args.device if args.device >= 0 else "cpu"
    seeds = args.seeds
    dataset_name = args.dataset
    max_epoch = args.max_epoch
    max_epoch_f = args.max_epoch_f
    num_hidden = args.num_hidden
    num_layers = args.num_layers
    encoder_type = args.encoder
    decoder_type = args.decoder
    replace_rate = args.replace_rate

    optim_type = args.optimizer 
    loss_fn = args.loss_fn

    lr = args.lr
    weight_decay = args.weight_decay
    lr_f = args.lr_f
    weight_decay_f = args.weight_decay_f
    linear_prob = args.linear_prob
    load_model = args.load_model
    save_model = args.save_model
    logs = args.logging
    use_scheduler = args.scheduler
    pooling = args.pooling
    deg4feat = args.deg4feat
    batch_size = args.batch_size

    #Mahmoud
    # torch.manual_seed(args.runseed)
    # np.random.seed(args.runseed)
    # device = torch.device("cuda:" + str(args.device)) if torch.cuda.is_available() else torch.device("cpu")
    # if torch.cuda.is_available():
    #     torch.cuda.manual_seed_all(args.runseed)


    print("DATASET SELECTED --", dataset_name)
    graphs, (num_features, num_classes) = load_graph_classification_dataset(dataset_name, deg4feat=deg4feat)
    args.num_features = num_features

    train_idx = torch.arange(len(graphs))
    train_sampler = SubsetRandomSampler(train_idx)
    
    train_loader = GraphDataLoader(graphs, sampler=train_sampler, collate_fn=collate_fn, batch_size=batch_size, pin_memory=True)
    eval_loader = GraphDataLoader(graphs, collate_fn=collate_fn, batch_size=batch_size, shuffle=False)

    if pooling == "mean":
        pooler = AvgPooling()
    elif pooling == "max":
        pooler = MaxPooling()
    elif pooling == "sum":
        pooler = SumPooling()
    else:
        raise NotImplementedError

    acc_list = []
    for i, seed in enumerate(seeds):
        print(f"####### Run {i} for seed {seed}")
        set_random_seed(seed)

        if logs:
            logger = TBLogger(name=f"{dataset_name}_loss_{loss_fn}_rpr_{replace_rate}_nh_{num_hidden}_nl_{num_layers}_lr_{lr}_mp_{max_epoch}_mpf_{max_epoch_f}_wd_{weight_decay}_wdf_{weight_decay_f}_{encoder_type}_{decoder_type}")
        else:
            logger = None

        model = build_model(args)
        model.to(device)
        optimizer = create_optimizer(optim_type, model, lr, weight_decay)

        if use_scheduler:
            logging.info("Use schedular")
            scheduler = lambda epoch :( 1 + np.cos((epoch) * np.pi / max_epoch) ) * 0.5
            # scheduler = lambda epoch: epoch / warmup_steps if epoch < warmup_steps \
                    # else ( 1 + np.cos((epoch - warmup_steps) * np.pi / (max_epoch - warmup_steps))) * 0.5
            scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=scheduler)
        else:
            scheduler = None
            
        if not load_model:
            model = pretrain(model, pooler, (train_loader, eval_loader), optimizer, max_epoch, device, scheduler, num_classes, lr_f, weight_decay_f, max_epoch_f, linear_prob,  logger)
            model = model.cpu()

        if load_model:
            logging.info("Loading Model ... ")
            model.load_state_dict(torch.load("checkpoint.pt"))
        if save_model:
            logging.info("Saveing Model ...")
            torch.save(model.state_dict(), "checkpoint.pt")

        model = model.to(device)
        # if not args.filename == "":
        #     fname = 'runs/traingraph_cls_runseed' + str(args.runseed) + '/' + args.filename
        #     # delete the directory if there exists one
        #     if os.path.exists(fname):
        #         shutil.rmtree(fname)
        #         print("removed the existing file.")
        #     writer = SummaryWriter(fname)

        model.eval()
        test_f1 = graph_classification_evaluation(model, pooler, eval_loader, num_classes, lr_f, weight_decay_f, max_epoch_f, device, mute=False)
        acc_list.append(test_f1)
        # if not args.filename == "":
        #     writer.add_scalar('data/train auc', acc_list, epoch)
        #print("")
    final_acc, final_acc_std = np.mean(acc_list), np.std(acc_list)
    print(f"# final_acc: {final_acc:.4f}±{final_acc_std:.4f}")



if __name__ == "__main__":
    args = build_args()
    if args.use_cfg:
        args = load_best_configs(args, "configs.yml")
    print(args)
    main(args)
